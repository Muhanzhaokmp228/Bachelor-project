API reference
========================

.. automodule:: spherical_stats
   :members:
   :undoc-members:
   :show-inheritance:
